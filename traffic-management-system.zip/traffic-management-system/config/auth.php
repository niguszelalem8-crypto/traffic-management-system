<?php
require_once __DIR__.'/database.php';
function require_login(): void { if (empty($_SESSION['user'])) { header('Location: login.php'); exit; } }
function require_role(string ...$roles): void { require_login(); if (!in_array($_SESSION['user']['role'], $roles, true)) { http_response_code(403); exit('403 Forbidden: your account cannot access this page.'); } }
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function csrf_token(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function verify_csrf(): void { if ($_SERVER['REQUEST_METHOD']==='POST' && !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(419); exit('Session security check failed. Refresh and try again.'); } }
function notice(string $message, string $type='success'): void { $_SESSION['flash']=['message'=>$message,'type'=>$type]; }
function take_notice(): ?array { $n=$_SESSION['flash']??null; unset($_SESSION['flash']); return $n; }
